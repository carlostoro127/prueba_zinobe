$(document).ready(function() {
    	$('#tabla').dataTable();
	} );